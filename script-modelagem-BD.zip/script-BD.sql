create database livraria;

use livraria;

create table autor (
idautor int primary key auto_increment,
nome varchar(100)
);

create table genero (
idgenero int primary key auto_increment,
nome varchar(45)
);

create table livro (
id int primary key auto_increment,
titulo varchar(50),
preco_de_compra int,
preco_de_venda int,
quantidade int,
fkautor int,
fkgenero int,
foreign key (fkautor) references autor,
foreign key (fkgenero) references genero
);

insert into genero (nome) values 
("romance"),
("terror"),
("comédia"),
("ação");
